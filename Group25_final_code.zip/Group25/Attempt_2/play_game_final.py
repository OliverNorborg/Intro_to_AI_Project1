# -*- coding: utf-8 -*-
"""
Created on Tue Mar 15 10:59:07 2022

@author: Group 25
"""
from tree_builder import Tree, Leaf, Node 
from KalahaGame import Game
 
import MinMax_with_alpha_beta
from eval_function import utili_function

def result(node, a):#returns posible actions that can be taken
    children = node.get_children()
    return children[a]

game = Game()
game.printboard()
minmax = MinMax_with_alpha_beta.MinMax(utili_function, result, max_depth = 5)
#root = Node(game.get_state())



while not(game.emptyside()):
    
    if game.turn() == 0: #Player turn
        input_bowl = int(input("What bowl do you choose "))
        game.choose_bowl(input_bowl)
        game.printboard()
    else: #AI turn
        
        #make a tree with recusrsion = 3
        tree = Tree(3)
        print("AI is moving")
        
        #set the root of the tree
        tree.reset_root(Node(game))
        
        #biuld the tree from the root
        tree.build()
        
        #run a minimax search with alpha beta pruning
        value, best_move = minmax.alpha_beta(tree)
        
        #print the utility
        print(" {1} (utility: {0})".format(value, best_move+1))
        
        #make the best move for current state of the game
        game.choose_bowl(best_move+1)
        game.printboard()
    
    #check if one board side is empty
    if game.emptyside():
        game.final_score() #Print the final score of the game

game.final_score()
print("End of game")