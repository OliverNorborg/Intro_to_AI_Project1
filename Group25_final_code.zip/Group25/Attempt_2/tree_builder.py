# -*- coding: utf-8 -*-
"""
Created on Tue Mar 15 10:29:59 2022

@author: Group 25
"""
import copy
from KalahaGame import Game


class Node:
    def __init__(self, data):
        self.data = data
        self.children = {}

    def add_child(self, move, child):
        self.children[move] = child

    def getchild(self):
        return self.children

    def getdata(self):
        return self.data

    def adddata(self, data):
        self.data = data

    # Evaluation function
    def calculate_utility(self, fn):
        return fn(self.data)

class Leaf:
    def __init__(self, data):
        self.data = data
        
    def getdata(self):
        return self.data
    
    def calculate_utility(self, fn):
        return fn(self.data)


class Tree:
    def __init__(self, max_depth=1):
        #Set max_depth to an integer 
        self.max_depth = max_depth
        self.root = None
        
    def reset_root(self, root):
        self.root = root
    
    def build(self):
        self.build_tree(self.root)
        
    def build_tree(self, node, recursion=0):
        #Will be a recursion function that adds all the nodes until
        #the max depth is reached 
        if recursion >= self.max_depth:
            return
        
        #Add children (nodes) for all the possible moves 
        #6 different bowls
        
        for i in range(0,7):
            print ('move', i)
             
            board = copy.deepcopy(node.getdata())
            #These nodes will all be siblings
            
            if Game().choose_bowl(i): #make sure it is a valid move
                
                #check if the the action leads to a leaf of the tree
                if Game().emptyside():
                    #if game over add the child as a leaf to the tree
                    Game().game_over()
                    Node(node).add_child(move=i, child=Leaf(board))
                    
                else:
                    #else add the child as a normal node of the tree
                    Node(node).add_child(move=i, child=Node(board))
                    
        
        
        for child in node.getchild().values():
            #print('Child', child)
            #Check if a child is a node
            if isinstance(child, Node):
                #print("Child is node", child)
                self.build_tree(child, recursion + 1)
