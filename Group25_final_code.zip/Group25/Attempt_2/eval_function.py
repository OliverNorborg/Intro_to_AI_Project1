# -*- coding: utf-8 -*-
"""
Created on Fri Mar 18 10:06:40 2022

@author: Group 25
"""
from KalahaGame import Game

def utili_function(game):
    utility = 0
    # Compute player 1 score
    player_1_score = game.state[1][-1]

    # Compute player 2 score
    player_2_score = game.state[1][-1]

    utility += player_2_score - player_1_score
    return utility
