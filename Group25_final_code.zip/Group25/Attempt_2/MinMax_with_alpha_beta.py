# -*- coding: utf-8 -*-
"""
Created on Sun Mar 13 13:46:57 2022

@author: Group 25
"""
import copy

## needs to iport node/leaf from tree generated every turn
from tree_builder import Leaf
from KalahaGame import Game

#game = Game()

class MinMax:
    
    def __init__(self, utility_func, result, max_depth=5):
        self.utility_func = utility_func
        self.result = result
        self.max_depth = max_depth
    
    def terminal_test(self, node, leaf, current_depth):
        ## If the final game state is game over, or is of max depth
        ## calculate the utility
        if isinstance(node, Leaf) or current_depth >= self.max_depth:
            ## calculate the utility based on the evaluation func from node
            utility = node.calculate_utility(self.utility_func), 0
            return utility
        
    def Max(self, node, first_branch, second_branch, current_depth):
        
        
        ##Make terminal check
        
        if isinstance(node, Leaf) or current_depth >= self.max_depth:
            ## calculate the utility of the node
            return node.calculate_utility(self.utility_func), 0
        # get data from tree
        data = node.getdata()
        
        #init value set to -inf and best move to -1
        value = float ('-inf')
        best_move = -1
        
        ##Look trhough all actions (children of the node)
        for i in node.getchild().keys():
            c_data = copy.deepcopy(data) ##Make a copy of current game
            
            #Max func if AI, and min func if player
            result_node = self.result_func(node, i)
            if isinstance(data, Game):
                
                #check player turn 1 for AI and 2 for human player
                if result_node.getdata().get_player_turn()== 1:
                    
                    value = max(value, self.Max(result_node,first_branch, second_branch, current_depth + 1)[0])
                else:
                    value = max(value, self.Min(result_node,first_branch, second_branch, current_depth + 1 )[0])
            else:
                value = max(value, self.Min(result_node, first_branch, second_branch, current_depth + 1)[0])

        
            ## Reset game state, so the next itteration works with the correct node
            node.adddata(c_data)
            
            ##do alpha beta pruning of the branches
            
            if value >= second_branch:
                return value, best_move
            if value > first_branch:
                best_move = i
                
            first_branch = max(first_branch, value)
        print('V', value, 'Move', best_move)
        return value, best_move
    
            
        
            
            
            
    def Min(self,node, first_branch, second_branch,  current_depth):
        #Min is more or less just a copy of max, but taking min values ofcourse
        
        ##Make terminal check
        
        if isinstance(node, Leaf) or current_depth >= self.max_depth:
            ## calculate the utility based on the evaluation func from node
            return node.calculate_utility(self.utility_func), 0
        # get data from tree
        data = node.getdata()
        
        #init value
        value =float ('-inf') 
        best_move = -1
        print ('keys_min', node.getchild().keys())
        ##Look trhough all actions (children of the node)
        for i in node.getchild().keys():
            c_data = copy.deepcopy(data) ##Make a copy of current game
            
            #Max func if AI, and min func if player
            result_node = self.result_func(node, i)
            if isinstance(data, Game):
                if result_node.getdata().get_player_turn()== 1:
                    value = min(value, self.Max(result_node,first_branch, second_branch, current_depth + 1)[0])
                else:
                    value = min(value, self.Min(result_node,first_branch, second_branch, current_depth + 1)[0])
            else:
                value = min(value, self.Max(result_node,first_branch, second_branch, current_depth + 1)[0])

            ## Reset game state, so the next itteration works with the correct node
            node.adddata(c_data)
            
            ##do alpha beta pruning of the branches
            
            if value <= first_branch:
                return value, best_move
            if value > second_branch:
                best_move = i
                
            second_branch = min(second_branch, value)
        #print('V', value, 'Move', best_move)
        return value, best_move
    
    def alpha_beta(self, tree):
        value , best_move = self.Max(tree.root,float('-inf'), float('inf'), 0)
        return value, best_move